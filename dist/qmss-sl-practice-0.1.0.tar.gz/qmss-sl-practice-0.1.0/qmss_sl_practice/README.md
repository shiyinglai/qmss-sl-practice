# qmss-sl-practice 

![](https://github.com/shiyinglai/qmss_sl_practice/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/shiyinglai/qmss_sl_practice/branch/main/graph/badge.svg)](https://codecov.io/gh/shiyinglai/qmss_sl_practice) ![Release](https://github.com/shiyinglai/qmss_sl_practice/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/qmss_sl_practice/badge/?version=latest)](https://qmss_sl_practice.readthedocs.io/en/latest/?badge=latest)

This is a practice package.

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ qmss_sl_practice
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://qmss_sl_practice.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/shiyinglai/qmss_sl_practice/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
