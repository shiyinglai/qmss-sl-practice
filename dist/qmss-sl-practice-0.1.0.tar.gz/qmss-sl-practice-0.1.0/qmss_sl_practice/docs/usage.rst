=====
Usage
=====

To use qmss-sl-practice in a project::

    import qmss_sl_practice
